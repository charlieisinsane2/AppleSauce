

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

To run build_init, place the following files in this directory:

 - 'mcp918.zip' (mod coder pack for minecraft 1.8.8)
 - '1.8.8.jar` (jar file for minecraft 1.8.8)
 - '1.8.json' (assets index for minecraft 1.8)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


Notes on assetsIndexTransformer.json:

Recommended allowed samples:
 - 16000
 - 22050
 - 32000
 - 44100
 - 48000

Recommended allowed bitrates:
 - 48
 - 64
 - 80
 - 96
 - 112
 - 128
