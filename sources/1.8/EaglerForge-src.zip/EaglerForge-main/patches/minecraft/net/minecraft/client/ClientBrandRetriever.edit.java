
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> INSERT  2 : 4  @  2

+ import static net.lax1dude.eaglercraft.v1_8.EaglercraftVersion.projectForkName;
+ 

> CHANGE  2 : 3  @  2 : 3

~ 		return projectForkName;

> EOF
