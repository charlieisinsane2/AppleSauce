
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  3 : 4  @  3 : 4

~ 

> CHANGE  31 : 32  @  31 : 32

~ 		List<Entity> list;

> CHANGE  12 : 14  @  12 : 13

~ 			for (int i = 0, l = list.size(); i < l; ++i) {
~ 				Entity entity = list.get(i);

> EOF
