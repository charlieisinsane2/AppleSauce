#!/bin/sh
java -jar buildtools/BuildTools.jar clean