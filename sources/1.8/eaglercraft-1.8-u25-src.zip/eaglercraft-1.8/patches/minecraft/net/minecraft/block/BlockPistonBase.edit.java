
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  3 : 4  @  3 : 7

~ 

> CHANGE  85 : 88  @  85 : 86

~ 		EnumFacing[] facings = EnumFacing._VALUES;
~ 		for (int i = 0; i < facings.length; ++i) {
~ 			EnumFacing enumfacing = facings[i];

> CHANGE  10 : 12  @  10 : 11

~ 			for (int i = 0; i < facings.length; ++i) {
~ 				EnumFacing enumfacing1 = facings[i];

> EOF
