
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 4  @  2 : 3

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;
~ 

> DELETE  1  @  1 : 3

> CHANGE  5 : 6  @  5 : 6

~ 	private final EaglercraftRandom rand = new EaglercraftRandom();

> EOF
