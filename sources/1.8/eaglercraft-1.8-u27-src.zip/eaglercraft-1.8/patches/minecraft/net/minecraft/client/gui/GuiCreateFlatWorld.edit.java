
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> INSERT  3 : 6  @  3

+ 
+ import net.lax1dude.eaglercraft.v1_8.opengl.GlStateManager;
+ import net.lax1dude.eaglercraft.v1_8.opengl.WorldRenderer;

> DELETE  2  @  2 : 9

> DELETE  2  @  2 : 3

> CHANGE  61 : 62  @  61 : 62

~ 	protected void actionPerformed(GuiButton parGuiButton) {

> EOF
